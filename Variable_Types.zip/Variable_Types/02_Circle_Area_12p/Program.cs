﻿using System;

namespace _02_Circle_Area_12p
{
    class Program
    {
        static void Main()
        {
            double r = double.Parse(Console.ReadLine());
            Console.WriteLine("{0:f12}", Math.PI * r * r);

        }
    }
}