﻿using System;

namespace _09_Refactor_Nums
{
    class Program
    {
        static void Main()
        {
            int num1 = int.Parse(Console.ReadLine());

            for (int i = 1; i <= num1; i++)
            {
                int sum = 0;
                int num2 = i;

                while (num2 > 0)
                {
                    sum += num2 % 10;
                    num2 = num2 / 10;
                }

                bool result = (sum == 5) || (sum == 7) || (sum == 11);
                Console.WriteLine("{0} -> {1}", i, result);                
            }
        }
    }
}