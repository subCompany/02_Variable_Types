﻿using System;

namespace _01_Centuries_to_Minutes
{
    class Program
    {
        static void Main()
        {
            Console.Write("Centuries = ");
            int cent = int.Parse(Console.ReadLine());
            int y = cent * 100;
            int d = (int)(y * 365.2422);
            int h = 24 * d;
            int m = 60 * h;
            Console.WriteLine("{0} centuries = {1} years = {2} days = {3} hours = {4} minutes", cent, y, d, h, m);
        }
    }
}