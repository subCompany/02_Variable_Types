﻿using System;

namespace _08_Refactor_Vol_Pyramid
{
    class Program
    {
        static void Main()
        {
            double length, width, hight = 0;

            Console.Write("Length: ");
            length = double.Parse(Console.ReadLine());

            Console.Write("Width: ");
            width = double.Parse(Console.ReadLine());

            Console.Write("Height: ");
            hight = double.Parse(Console.ReadLine());

            double V = (length * width * hight) / 3;
            Console.WriteLine("Pyramid Volume: {0:F2}", V);
        }
    }
}