﻿using System;

namespace _04_Elevator
{
    class Program
    {
        static void Main()
        {
            int c = int.Parse(Console.ReadLine());
            int p = int.Parse(Console.ReadLine());
            int course = (int)Math.Ceiling((double)c / p);
            Console.WriteLine(course);
        }
    }
}