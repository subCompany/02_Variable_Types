﻿using System;

namespace _07_Greeting
{
    class Program
    {
        static void Main()
        {
            string fName = Console.ReadLine();
            string lName = Console.ReadLine();
            string ageS = Console.ReadLine();

            int age = int.Parse(ageS);

            Console.WriteLine($"Hello, {fName} {lName}.\r\nYou are {age} years old.");
        }
    }
}